var a = "word";
console.log(a);
